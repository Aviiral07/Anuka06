# Anuka — UI/UX Design Notes (Sprint 1)

**Assigned to:** Praduman
**Deliverables covered:** Home Screen Design · Need Posting Flow · User Profile Screen
**Companion file:** `anuka_design_system.html` — open in any browser for a clickable, mobile-sized prototype of all three screens plus the design system reference.

---

## 1. Concept

Anuka's whole job is one behavior loop: **post a need → someone responds.** The design treats every need as a small paper notice pinned to a neighbourhood board, rather than a generic "card" in a generic app. That idea drives every screen:

- A warm, paper-toned background instead of a stark white app canvas.
- A coloured left-edge bar on every notice that encodes urgency at a glance (Food = sage, Medical = pine, Emergency = terracotta, Other = marigold).
- A small "pin" dot on each card, with a soft lifted shadow, so the feed reads like a board you'd actually walk up to in a building lobby.

This is the one decorative idea in the system (the "signature element" per design practice) — everything else stays quiet and functional so the board is fast to scan.

## 2. Design system

| Token | Value | Used for |
|---|---|---|
| Pine `#1F5C4F` | Primary | Primary buttons, header, brand mark |
| Marigold `#E8A33D` | Accent | Selected states, stat highlights, "Other" category, pin dot |
| Terracotta `#C1502E` | Urgent | Emergency category, danger actions |
| Sage `#7FA98E` | Status | "Open" status, Food category |
| Paper `#FAF6EF` | Background | App background |
| Ink `#1C2420` | Text | Primary text |

- **Display type:** Sora (600/700) — screen titles, card titles, brand mark.
- **Body type:** Inter (400/600) — all body copy, form labels, buttons.
- **Meta type:** IBM Plex Mono (500) — timestamps, location tags, step labels. Gives the "dispatch board" feel without resorting to icons-only.
- **Radius:** Cards 18px · Buttons 14px · Input fields 12px · Chips/pills fully rounded.
- **Spacing:** 4pt base scale (4/8/12/16/24/32).

This is intentionally a small, named token set so Aryan (frontend) can drop it straight into Flutter's `ThemeData` / `ColorScheme` with minimal translation — see Section 5.

## 3. Screen-by-screen

### Home Screen (the board)
- Header: brand mark, avatar (tap → Profile), a one-line greeting, and a small live "pulse" pill showing the count of open needs nearby — gives a sense of activity without needing a map for Sprint 1.
- Feed: latest-first list of notice cards. Each card shows title, status chip, category/location/time tags, optional description, and one primary action (`I Can Help` if open, `Mark Completed` if the viewer is the creator/helper of a need that's being helped, nothing if completed) — this mirrors the exact logic already in `feed_screen.dart` and `need_card.dart`.
- Empty state: framed as an invitation ("Be the first to post a real need…") rather than a dead end, matching the existing empty-state copy in the code.
- Primary action: a fixed `+ Post a need` button pinned to the bottom of the screen.

### Need Posting Flow
Four short steps instead of one long form, mapped directly to the fields already in `create_need_screen.dart`:

1. **What's the need?** — category tiles (Food / Medical / Emergency / Other). Category comes first because it's the thing that sets the notice's colour-code on the board.
2. **Tell us more** — Title (required) + Description (optional).
3. **Where should help arrive?** — Location field, with a "use current location" affordance reserved for when location services land (Shivank's workstream).
4. **Review & post** — a live preview of the exact notice card that will appear on the board, so posting never feels like a leap of faith.

Progress is shown as four quiet bars rather than numbered circles — there's nothing to count, just a sense of how much is left.

### User Profile Screen
Deliberately scoped to what Sprint 1's data already supports — no new Firestore collections needed:

- Avatar (initial) + name + join date, sourced from the existing `users` collection (`AppUser.name`, `AppUser.createdAt`).
- A small stat strip (needs posted / people helped) — computed client-side from the `needs` collection, not stored, so it ships without a schema change.
- "My needs" — a short list of the signed-in user's own posted needs and their status.
- Settings rows: Edit name, Notification preferences (placeholder for later), About Anuka, Sign out.

## 4. What's intentionally out of scope for Sprint 1
- Map view / pin-drop location picking (Shivank's Google Maps integration lands separately; the location field stays a plain text input for now).
- Push notifications.
- Editing a profile photo (initials avatar only).
- Anything beyond the three screens in this sprint's brief.

## 5. Handoff notes for development (Aryan)
- The existing `ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal))` in `app.dart` can be replaced with explicit swatches from Section 2 for an exact match — happy to pair on this.
- Status-chip colours here use the same three states already modelled in `NeedStatus`/`NeedStatusX` (`open`, `helping`, `completed`) — no logic changes needed, just colour/label swap in `_StatusChip` inside `need_card.dart`.
- The category left-bar colour can be driven directly off `NeedItem.category` with a simple lookup map (`Food → sage`, `Medical → pine`, `Emergency → terracotta`, anything else → marigold).
- The posting flow's 4 steps can be built as a `PageView` or a simple `int currentStep` + `IndexedStack` in Flutter, validating only the fields relevant to the current step (title in step 2, location in step 3) rather than the whole form at once like today's single-page version.
- All type, spacing, and radius values are listed as literal tokens in the HTML/CSS for `anuka_design_system.html` (search for `:root` at the top of the file) if it's easier to copy values directly than re-derive them.

## 6. Evidence checklist (per Sprint 1 plan)
- [x] Mobile-first design — every screen built and reviewed at 360×760, no desktop-first layouts.
- [x] Consistent design system — single token set (colour/type/spacing/radius) applied identically across all three screens; reference panel included in the prototype file.
- [ ] Figma file — not produced in this pass (no Figma access from this environment). `anuka_design_system.html` is offered as the developer-ready substitute: it's a live, clickable, exact-colour/spacing reference Aryan can read pixel values straight out of. If a Figma file is still required for the evidence trail, these screens can be rebuilt there next — happy to write out exact frame-by-frame specs to speed that up.
- [x] Screen exports — see `shot_design.png`, `shot_home.png`, `shot_post.png`, `shot_post_review.png`, `shot_profile.png`.
- [x] Design notes — this document.
